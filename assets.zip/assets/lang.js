let head_title = {
    "en" : "Library Management System",
    "sp" : "Sistema de gestión de bibliotecas"
}

let login_title = {
    "en" : "Login to your account",
    "sp" : "Ingrese a su cuenta"
}

let login_id = {
    "en" : "Login Id",
    "sp" : "Ingresar identificación"    
}

let password = {
    "en" : "Password",
    "sp" : "Clave"
}

let submit = {
    "en" : "Submit",
    "sp" : "Enviar"
}

let register = {
    "en" : "Register",
    "sp" : "Registrarse"
}