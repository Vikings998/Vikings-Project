$(document).ready(function () {
    console.log("ready!");
    $("#submit").prop("disabled", true);
    $("#register").submit(function (event) {
        event.preventDefault();
        console.log(JSON.stringify(event))
        registerUser();
    })
});

function registerUser() {
    console.log("Submitted");
    console.log(JSON.stringify($("#register")));
    console.log($("#loginid").val())
    console.log($("#password").val())

    data = {
        "loginId": $("#loginid").val(),
        "password": $("#password").val(),
        "name": $("#name").val(),
        "email": $("#email").val(),
        "contact": $("#contact").val(),
        "type": "student"
    }

    console.log(data)
    console.log(JSON.stringify(data))

    $.ajax({
        type: "post",
        contentType: ["application/json; charset=utf-8", "text/plain;charset=UTF-8"],
        url: "http://localhost:8080/user/register",
        data: JSON.stringify(data),
        success: function (data) {
            if (data == "User Exists") {
                $('#invaliderror').text("Existing User..");
                $('#invaliderror').css("visibility", "visible");
                $(".errorborder").css({ "border-style": "solid", "border-width": "2px", "border-color": "red" });
            }
            else {                
                $('#invaliderror').css("visibility", "hidden")
                $(".errorborder").css({ "border-style": "solid", "border-width": "2px", "border-color": "green" })                               
                window.location.href = filepath+"/login/login.html";
            }
            console.log("Register connection successful");
            console.log(JSON.stringify(data));
        }
    })

    return false;
}


function loginidValidation(){
    $("#submit").prop("disabled", true);
    var val = $("#loginid").val();
    if (val.length <6){
        $("#submit").prop("disabled", true);
        $("#loginid").parent().parent().find("p").text("LoginId should be atleast of 6 characters");
        $("#loginid").removeClass("validInput");
        $("#loginid").addClass("invalidInput");
    }
    else{
        $("#submit").prop("disabled", false);
        $("#loginid").parent().parent().find("p").text("");        
        $("#loginid").removeClass("invalidInput");
        $("#loginid").addClass("validInput");
    }
}

function nameValidation(){
    $("#submit").prop("disabled", true);
    var val = $("#name").val();
    if (val.length <5){
        $("#submit").prop("disabled", true);
        $("#name").parent().parent().find("p").text("Name should be minimum of 5 characters");
        $("#name").removeClass("validInput");
        $("#name").addClass("invalidInput");
    }
    else{
        $("#submit").prop("disabled", false);
        $("#name").parent().parent().find("p").text("");        
        $("#name").removeClass("invalidInput");
        $("#name").addClass("validInput");
    }
}

function passwordValidation(){
    $("#submit").prop("disabled", true);
    var val = $("#password").val();
    if (val.length <6){
        $("#submit").prop("disabled", true);
        $("#password").parent().parent().find("p").text("Password should be minimum of 6 characters");
        $("#password").removeClass("validInput");
        $("#password").addClass("invalidInput");
    }
    else{
        $("#submit").prop("disabled", false);
        $("#password").parent().parent().find("p").text("");        
        $("#password").removeClass("invalidInput");
        $("#password").addClass("validInput");
    }
}

function contactValidation(){
    $("#submit").prop("disabled", true);
    var val = $("#contact").val();
    if (val.length != 10){
        $("#submit").prop("disabled", true);
        $("#contact").parent().parent().find("p").text("contact should be of 10 characters");
        $("#contact").removeClass("validInput");
        $("#contact").addClass("invalidInput");
    }
    else{
        $("#submit").prop("disabled", false);
        $("#contact").parent().parent().find("p").text("");        
        $("#contact").removeClass("invalidInput");
        $("#contact").addClass("validInput");
    }
}


