$(document).ready(function () {
    console.log("Librarian Home page ready!");
    getAllUserDetails();
    $("#saveuser").hide()
    $("#canceluser").hide()
});

function getAllUserDetails() {
    console.log("All student user details");

    var url = "http://localhost:8080/checkin/penalty";
    $.ajax({
        type: "get",
        url: url,
        success: function (data) {
            console.log("Get all User Details");
            console.log(JSON.stringify(data));
            $("table tbody tr").remove();
            $.each(data, function (index, value) {
                console.log(index, value);
                var userhtml =
                    '<tr class="userdetail">' +
                    '<th scope="row">' +
                    '<form>' +
                    '<div class="form-check">' +
                    '<input type="checkbox" onclick="addUserList(event)" id="' + value["userId"] + '" name="userId" class="form-check-input" >' +
                    '</div>' +
                    '</form>' +
                    '</th>' +
                    '<td>' +
                    '<input type="text" class="form-control usereditfield" id="loginId" disabled value="' + value["loginId"] + '" required name="loginId"></input>' +
                    '</td>' +
                    '<td>' +
                    '<input type="text" class="form-control usereditfield" id="name" disabled value="' + value["name"] + '" required name="name"></input>' +
                    '</td>' +
                    '<td>' +
                    '<input type="text" class="form-control usereditfield" id="email" disabled value="' + value["email"] + '" required name="email"></input>' +
                    '</td>' +
                    '<td>' +
                    '<input type="text" class="form-control usereditfield" id="contact" disabled value="' + value["contact"] + '" required name="contact"></input>' +
                    '</td>' +
                    '<td>' +
                    '<input type="text" class="form-control usereditfield" id="penalty" disabled value="' + value["penalty"] + '" required name="penalty"></input>' +
                    '</td>' +
                    '</tr>';

                $("table.userslist tbody").append(userhtml);
            }
            );
        }
    })
}

function homepage() {
    console.log(filepath + "/home/libraryhome.html");
    window.location.href = filepath + "/home/libraryhome.html";
}

function addUserList(event) {
    if ($("#" + event.target.id).prop("checked") == true) {
        $("#edituser").prop("disabled", false);
    }
    else {
        $("#edituser").prop("disabled", true);
    }
    $("#saveuser").hide();
    $("#canceluser").hide();
}

function editUser() {
    $("#loginId").prop("disabled", false);
    $("#username").prop("disabled", false);
    $("#email").prop("disabled", false);
    $("#contact").prop("disabled", false);
    $("#name").prop("disabled", false);
    $("#penalty").prop("disabled", false);
    $("#saveuser").show();
    $("#canceluser").show();
}


function saveUser() {
    var userDetails = {}
    var url = "http://localhost:8080/checkin/updatepenalty";
    $.each($("input").prop("disabled", false), function (index, element) {
        console.log(index, element);
        if (index == 0) {
            userDetails["userId"] = element["id"];
        }
        else {
            userDetails[element["id"]] = element["value"];
        }
    });
    console.log(JSON.stringify(userDetails));

    $.ajax({
        type: "POST",
        url: url,
        contentType: "application/json",
        data: JSON.stringify(userDetails),
        dataType: "json",
        success: function (data) {
            console.log("User Details Updated Successfully");
        },
        complete: function (data) {
            $("#saveuser").hide();
            $("#canceluser").hide();
            $("#edituser").prop("disabled", true);
            getAllUserDetails();
        }
    })
}

function cancelUser() {
    $("#saveuser").hide();
    $("#canceluser").hide();
    $("#edituser").prop("disabled", true);
    getAllUserDetails();
}



