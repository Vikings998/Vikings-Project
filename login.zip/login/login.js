$(document).ready(function () {
    window.history.forward();
    function noBack() {
        window.history.forward();
    }
    console.log("ready!");
    $("#submit").prop("disabled", true);
    $("#login").submit(function (event) {
        event.preventDefault();
        console.log(JSON.stringify(event))
        checkCredentials();
    })
});

function setLanguage(lang){
    console.log("lang"+lang);
    console.log(head_title[lang]);
    localStorage.setItem("langCode", lang);
    $(".head_title").text(head_title[lang]);
    $(".login_title").text(login_title[lang]);
    $(".login_id").text(login_id[lang]);
    $(".password").text(password[lang]);
    $(".submit").text(submit[lang]);
    $(".register").text(register[lang]);
}

function checkCredentials() {
    console.log("Submitted");
    console.log(JSON.stringify($("#login")));
    console.log($("#loginid").val())
    console.log($("#password").val())

    data = {
        "loginId": $("#loginid").val(),
        "password": $("#password").val(),
    }

    console.log(data)
    console.log(JSON.stringify(data))

    $.ajax({
        type: "post",
        contentType: "application/json",
        url: "http://localhost:8080/user/login",
        data: JSON.stringify(data),
        dataType: "json",
        success: function (data) {
            $('#invaliderror').css("visibility", "hidden")
            $(".errorborder").css({ "border-style": "solid", "border-width": "2px", "border-color": "green" })
            console.log("Login connection successful");
            console.log(JSON.stringify(data));
            console.log(window.location);
            localStorage.setItem("userid", data.userId);
            if (data.type == "student") {
                console.log(filepath + "/home/studenthome.html");
                window.location.href = filepath + "/home/studenthome.html";
            }
            else {
                console.log(filepath + "/home/libraryhome.html");
                window.location.href = filepath + "/home/libraryhome.html";
            }
        },
        error: function (data) {
            console.log("Invalid Login Credentials");
            // $("#invaliderror").show()
            $('#invaliderror').css("visibility", "visible")
            $(".errorborder").css({ "border-style": "solid", "border-width": "2px", "border-color": "red" })
        }
    })

    return false;
}

function loginIdValidation() {
    $("#submit").prop("disabled", true);
    var val = $("#loginid").val();
    if (val.length < 6) {
        $("#submit").prop("disabled", true);
        $("#loginid").parent().parent().find("p").text("LoginId should be atleast of 6 characters");
        $("#loginid").removeClass("validInput");
        $("#loginid").addClass("invalidInput");
    }
    else {
        $("#submit").prop("disabled", false);
        $("#loginid").parent().parent().find("p").text("");
        $("#loginid").removeClass("invalidInput");
        $("#loginid").addClass("validInput");
    }
}

function passwordValidation() {
    $("#submit").prop("disabled", true);
    var val = $("#password").val();
    if (val.length < 6) {
        $("#submit").prop("disabled", true);
        $("#password").parent().parent().find("p").text("Password should be atleast of 6 characters");
        $("#password").removeClass("validInput");
        $("#password").addClass("invalidInput");
    }
    else {
        $("#submit").prop("disabled", false);
        $("#password").parent().parent().find("p").text("");
        $("#password").removeClass("invalidInput");
        $("#password").addClass("validInput");
    }
}

