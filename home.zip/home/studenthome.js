requestedBooksList = []

$(document).ready(function () {
    console.log("Home page ready!");
    getPenalty();
    getUserDetails();
    getAvailableBooks();
    $("#request").prop("disabled", true)
    $("#saveuser").hide()
    $("#canceluser").hide()
});



function booksCreation(bookslist) {
    $("table.bookslist tbody").find("tr").remove()
    for (book in bookslist) {
        console.log(bookslist[book]);
        var bookhtml = '<tr>' +
            '<th scope="row">' +
            '<form>' +
            '<div class="form-check">' +
            '<input type="checkbox" onclick="addRequestBook(event)" class="form-check-input" id=book' + bookslist[book].bookId + '>' +
            '</div>' +
            '</form>' +
            '</th>' +
            '<td class="font-size">' +
            '<p>' + bookslist[book].bookName + '</p>' +
            '</td>' +
            '<td class="font-size">' +
            '<p>' + bookslist[book].author + '</p>' +
            '</td>' +
            '<td class="font-size">' +
            '<p>' + bookslist[book].publication + '</p>' +
            '</td>' +
            '</tr>'
        console.log(bookhtml)
        $("table.bookslist tbody").append(bookhtml)
    }
}

function getUserDetails() {
    var userid = localStorage.getItem("userid");
    var url = "http://localhost:8080/user/userDetails/" + parseInt(localStorage.getItem("userid"))
    console.log(url)
    console.log(userid)
    $.ajax({
        type: "get",
        url: url,
        success: function (data) {
            console.log("user data " + data)
            userDetails = data.split(",")
            userDetailsDict = {
                "userid": userDetails[0],
                "name": userDetails[1],
                "email": userDetails[2],
                "contact": userDetails[3],
                "type": userDetails[4],
                "taken": userDetails[5],
                "approved": userDetails[6],
                "pending": userDetails[7],
                "returned": userDetails[8],
                "non-returned": userDetails[9]
            }
            $(".usereditfield").remove()
            $("#user p").append('<input type="text" class="usereditfield background-color" value = "' + userDetails[1] + '" disabled></input>');
            $("#user div.userdetails tr").find("td").each(function (index) {
                if (index + 2 <= 3) {
                    $(this).append('<input type="text" class="usereditfield font-size background-color" value = ' + userDetails[index + 2] + ' disabled></input>');
                }
                else {
                    $(this).text(userDetails[index + 2])
                }
            }
            )
        }
    })
}

function getAvailableBooks() {
    var url = "http://localhost:8080/book/available"
    console.log(url)
    $.ajax({
        type: "get",
        url: url,
        success: function (data) {
            console.log("available books " + JSON.stringify(data))
            booksCreation(data)
        }

    })
}



function search(event) {
    console.log("search box clicked");
    console.log(event.type);
    console.log($("#search").val());
    if ($("#search").val().length == 0) {
        this.getAvailableBooks();
    }
    else {
        var url = "http://localhost:8080/book/search/" + $("#search").val()
        $.ajax({
            type: "get",
            url: url,
            success: function (data) {
                console.log("search data " + JSON.stringify(data))
                booksCreation(data)
            }
        })
    }
}


function addRequestBook(event) {
    console.log("request book")
    console.log(event.target.id)
    console.log($("#" + event.target.id).prop("checked"))
    var value = (event.target.id)
    value = value.slice(4, value.length)

    if ($("#" + event.target.id).prop("checked") == true) {
        console.log("checked")
        requestedBooksList.push(value)
    }
    else {
        console.log("unchecked")
        requestedBooksList.splice(requestedBooksList.indexOf(value), 1)
    }

    if (requestedBooksList.length == 0) {
        $("#request").prop("disabled", true)
    }
    else {
        $("#request").prop("disabled", false)
    }

}


function requestBook() {
    console.log("request book function");
    var url = "http://localhost:8080/checkin/request"
    var bookslist = {
        "userId": [parseInt(localStorage.getItem("userid"))],
        "bookslist": requestedBooksList
    }
    $.ajax({
        type: "post",
        contentType: "application/json",
        data: JSON.stringify(bookslist),
        dataType: "json",
        url: url,
        success: function (data) {
            console.log("request book " + JSON.stringify(data));
        },
        complete: function (data) {
            getAvailableBooks();
        }
    })
}


function checked_in() {
    console.log("Checked In Books");
    window.location.href = filepath + "/checked_in/checked_in.html";
}

function editUserDetails() {
    $("#saveuser").show()
    $("#canceluser").show()
    $(".usereditfield").prop("disabled", false)
    console.log("Edit User Details");
}

function saveUserDetails() {
    $("#saveuser").hide()
    $("#canceluser").hide()
    $(".usereditfield").prop("disabled", true)

    var userDetails = {
        "userId": localStorage.getItem("userid"),
        "name": $(".usereditfield:eq(0)").val(),
        "email": $(".usereditfield:eq(1)").val(),
        "contact": $(".usereditfield:eq(2)").val()

    }
    var url = "http://localhost:8080/user/userDetails"
    $.ajax({
        type: "post",
        contentType: "application/json",
        data: JSON.stringify(userDetails),
        dataType: "json",
        url: url,
        success: function (data) {
            console.log("User Details updated Successfully " + JSON.stringify(data));
        }
    })

    console.log("Save User Details" + JSON.stringify(userDetails));
}

function cancelUserDetails() {
    $("#saveuser").hide()
    $("#canceluser").hide()
    $(".usereditfield").prop("disabled", true)
    getUserDetails()
    console.log("Cancel User Details");
}


function getPenalty() {
    console.log("Penalty Function");
    var url = "http://localhost:8080/checkin/penalty/" + parseInt(localStorage.getItem("userid"));
    $.ajax({
        type: "get",
        contentType: "application/json",
        dataType: "json",
        url: url,
        success: function (data) {
            console.log("User Details updated Successfully " + JSON.stringify(data));
        }
    })
}


function logout() {
    window.location.href = filepath + "/login/login.html";
}