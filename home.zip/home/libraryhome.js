requestedBooksList = []

$(document).ready(function () {
    console.log("Librarian Home page ready!");
    getUserDetails();
    getAvailableBooks();
    $("#saveuser").hide()
    $("#canceluser").hide()
});



function booksCreation(bookslist) {
    $("table.bookslist tbody").find("tr").remove()
    for (book in bookslist) {
        console.log(bookslist[book]);
        var bookhtml = '<tr>' +
            '<th scope="row">' +
            '<form>' +
            '<div class="form-check">' +
            '<input type="checkbox" onclick="addRequestBook(event)" class="form-check-input" id=book' + bookslist[book].bookId + '>' +
            '</div>' +
            '</form>' +
            '</th>' +
            '<td>' +
            '<p>' + bookslist[book].bookName + '</p>' +
            '</td>' +
            '<td>' +
            '<p>' + bookslist[book].author + '</p>' +
            '</td>' +
            '<td>' +
            '<p>' + bookslist[book].publication + '</p>' +
            '</td>' +
            '</tr>'
        console.log(bookhtml)
        $("table.bookslist tbody").append(bookhtml)
    }
}

function getUserDetails() {
    var userid = localStorage.getItem("userid");
    var url = "http://localhost:8080/user/userDetails/lib/" + parseInt(localStorage.getItem("userid"))
    console.log(url)
    console.log(userid)
    $.ajax({
        type: "get",
        url: url,
        success: function (data) {
            console.log("user data " + JSON.stringify(data))
            userDetails = data.split(",")
            userDetailsDict = {
                "userid": userDetails[0],
                "name": userDetails[1],
                "email": userDetails[2],
                "contact": userDetails[3],
                "type": userDetails[4],
                "taken": userDetails[5],
                "approved": userDetails[6],
            }
            $(".usereditfield").remove()
            $("#user p").append('<input disabled type="text" id="name" class="usereditfield background-color" value = ' + userDetails[1] + '></input>');
            $("#user div.userdetails tr").find("td").each(function (index) {
                if (index + 2 <= 3) {
                    $(this).append('<input type="text" class="usereditfield font-size background-color" value = ' + userDetails[index + 2] + ' disabled></input>');
                }
                else {
                    $(this).text(userDetails[index + 2])
                }
            }
            )
            $("#name").val(userDetails[1])
        }
    })
}

function getAvailableBooks() {
    var url = "http://localhost:8080/book/available"
    console.log(url)
    $.ajax({
        type: "get",
        url: url,
        success: function (data) {
            console.log("available books " + JSON.stringify(data))
            booksCreation(data)
        }

    })
}



function search(event) {
    console.log("search box clicked");
    console.log(event.type);
    console.log($("#search").val());
    var url = "http://localhost:8080/book/search/" + $("#search").val()
    $.ajax({
        type: "get",
        url: url,
        success: function (data) {
            console.log("search data " + JSON.stringify(data))
            booksCreation(data)
        }
    })
}


function addRequestBook(event) {
    console.log("request book")
    console.log(event.target.id)
    console.log($("#" + event.target.id).prop("checked"))
    var value = (event.target.id)
    value = value.slice(4, value.length)

    if ($("#" + event.target.id).prop("checked") == true) {
        console.log("checked")
        requestedBooksList.push(value)
    }
    else {
        console.log("unchecked")
        requestedBooksList.splice(requestedBooksList.indexOf(value), 1)
    }

    if (requestedBooksList.length == 0) {
        $("#request").prop("disabled", true)
        $("#deleteBook").prop("disabled", true)
    }
    else {
        $("#request").prop("disabled", false)
        $("#deleteBook").prop("disabled", false)
    }

}


function requestBook() {
    console.log("request book function");
    var url = "http://localhost:8080/checkin/request"
    var bookslist = {
        "userId": [parseInt(localStorage.getItem("userid"))],
        "bookslist": requestedBooksList
    }
    $.ajax({
        type: "post",
        contentType: "application/json",
        data: JSON.stringify(bookslist),
        dataType: "json",
        url: url,
        success: function (data) {
            console.log("request book " + JSON.stringify(data));
        },
        complete: function (data) {
            getAvailableBooks();
        }
    })
}


function requestApproval() {
    console.log("Request Approval Books");
    window.location.href = filepath + "/requestapproval/requestapproval.html";
}

function editUserDetails() {
    $("#saveuser").show()
    $("#canceluser").show()
    $(".usereditfield").prop("disabled", false)
    console.log("Edit User Details");
}

function saveUserDetails() {
    $("#saveuser").hide()
    $("#canceluser").hide()
    $(".usereditfield").prop("disabled", true)

    var userDetails = {
        "userId": localStorage.getItem("userid"),
        "name": $(".usereditfield:eq(0)").val(),
        "email": $(".usereditfield:eq(1)").val(),
        "contact": $(".usereditfield:eq(2)").val()

    }
    var url = "http://localhost:8080/user/userDetails"
    $.ajax({
        type: "post",
        contentType: "application/json",
        data: JSON.stringify(userDetails),
        dataType: "json",
        url: url,
        success: function (data) {
            console.log("User Details updated Successfully " + JSON.stringify(data));
        }
    })

    console.log("Save User Details" + JSON.stringify(userDetails));
}

function cancelUserDetails() {
    $("#saveuser").hide()
    $("#canceluser").hide()
    $(".usereditfield").prop("disabled", true)
    getUserDetails()
    console.log("Cancel User Details");
}


function addBook() {
    console.log("addbook");
    $(".addbook").removeClass(".addbook");

    var bookhtml = '<tr class="addbook">' +
        '<th scope="row">' +
        '<form>' +
        '<div class="form-check col-1">' +
        '<input type="checkbox" disabled onclick="addRequestBook(event)" class="form-check-input" >' +
        '</div>' +
        '</form>' +
        '</th>' +
        '<td>' +
        '<input type="text" class="form-control col-1" required name="bookName"></input>' +
        '</td>' +
        '<td>' +
        '<input type="text" class="form-control col-1" required name="author"></input>' +
        '</td>' +
        '<td>' +
        '<input type="text" class="form-control col-1" required name="publication"></input>' +
        '</td>' +
        '<td>' +
        '<div class="row">' +
        // '<button class="btn btn-outline-secondary col-1" id="savebook" onclick="saveBook()"><img src="icons8-save-30.png"></img></button>' +
        '<img src="icons8-save-30.png" id="savebook" class="border-1"  onclick="saveBook()" width="30px" height="25px"></img>' +
        '<img src="icons8-cancel-25.png" id="cancelbook" class="border-1"  onclick="cancelBook()" width="30px" height="29px"></img>' +        
        '</div>' +
        '</td>' +
        '</tr>'


    $("table.bookslist tbody").prepend(bookhtml);
}

function saveBook() {
    console.log("Save Book");
    var bookDetail = {}
    $(".addbook input").each(function (index, element) {
        if (index != 0) {
            console.log(index, element.value, element.name);
            bookDetail[element.name] = element.value;
        }
    }
    );

    console.log(JSON.stringify(bookDetail));

    var url = "http://localhost:8080/book/add"
    $.ajax({
        type: "post",
        contentType: "application/json",
        data: JSON.stringify(bookDetail),
        dataType: "json",
        url: url,
        success: function (data) {
            console.log("User Details updated Successfully " + JSON.stringify(data));
        },
        complete: function (data) {
            $(".addbook").remove()
            getAvailableBooks()
        }
    });
}

function cancelBook() {
    console.log("Cancel Book");
    $(".addbook").remove()
}

function deleteBook() {
    console.log("delete Book");
    console.log(JSON.stringify(requestedBooksList));
    var url = "http://localhost:8080/book/delete"
    $.ajax({
        type: "delete",
        contentType: "application/json",
        data: JSON.stringify(requestedBooksList),
        dataType: "json",
        url: url,
        success: function (data) {
            console.log("Book Details deleted" + JSON.stringify(data));
        },
        complete: function (data) {
            getAvailableBooks();
            requestedBooksList = []
        }
    });
}


function allUserDetails() {
    console.log("All Student User Details");

    console.log(filepath + "/allstudentdetails/allstudentdetails.html");
    window.location.href = filepath + "/allstudentdetails/allstudentdetails.html";

}

function logout() {
    window.location.href = filepath + "/login/login.html";
}